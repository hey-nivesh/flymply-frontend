import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import ProblemSolution from "@/components/ProblemSolution";
import HowItWorks from "@/components/HowItWorks";
import Features from "@/components/Features";
import DemoVideo from "@/components/DemoVideo";
import LiveDemo from "@/components/LiveDemo";
import Footer from "@/components/Footer";
import GlobeBackground from "@/components/GlobeBackground";

export default function Home() {
  return (
    <div className="min-h-screen text-slate-50 selection:bg-sky-400 selection:text-slate-950">
      {/* Globe Background */}
      <GlobeBackground />

      {/* Page Content */}
      <div className="relative z-10">
        <Navbar />
        <main>
          <Hero />
          <ProblemSolution />
          <HowItWorks />
          <Features />
          <DemoVideo />
          <LiveDemo />
        </main>
        <Footer />
      </div>
    </div>
  );
}

# Task: Build the Flymply Landing Page (Next.js + Tailwind)

Build a professional, single-page landing page for "Flymply." Use the provided copy and technical requirements.

## 🛠 Tech Stack
- Framework: Next.js (App Router)
- Styling: Tailwind CSS
- Icons: Lucide React
- Animation: Framer Motion (for scroll reveals)

## 🎨 Design Guidelines
- **Theme:** High-end aerospace/SaaS. Professional, clean, and trustworthy.
- **Colors:** - Slate-950 (Deep Navy) for backgrounds.
  - Sky-400 (Aviation Blue) for primary accents/buttons.
  - Amber-500 and Rose-500 for warning states.
- **Components:** Use rounded-xl corners, subtle glassmorphism (bg-white/5), and crisp typography.

---

## 📄 Content & Structure

### 1. Hero Section
- **Headline:** Flymply — Predicting Clear‑Air Turbulence Before It Happens
- **Sub-headline:** An AI‑based early warning system that predicts the probability of clear‑air turbulence using real‑time weather data, helping pilots make safer decisions.
- **CTAs:** "View Live Demo" (Primary) and "How It Works" (Outline).

### 2. Problem Section (Pain Points)
- **Title:** The Problem with Clear‑Air Turbulence
- **Copy:** Clear‑air turbulence is one of the most unpredictable and dangerous events in aviation. It cannot be detected by onboard radar and often occurs without any visible warning. In most cases, pilots are informed only after turbulence has already been encountered, leaving little time to respond. This impacts passenger safety, comfort, and overall flight efficiency.

### 3. Solution Section (The Value)
- **Title:** A Predictive Approach to Turbulence Awareness
- **Copy:** Flymply uses artificial intelligence to analyze weather conditions and identify patterns that indicate a higher risk of clear‑air turbulence. Instead of reacting after turbulence occurs, the system predicts the likelihood of turbulence in advance and presents it as a simple percentage‑based risk score.
- **Safety Note:** (Small text) Flymply is a decision‑support system and does not control the aircraft.

### 4. How It Works (Stepper)
- **Steps:**
  1. Continuously collects real‑time weather data
  2. Processes key atmospheric indicators
  3. Uses AI to estimate turbulence risk
  4. Displays the risk as a live percentage on a dashboard
- **Closing:** A simple flow that turns complex data into clear insights.

### 5. Key Features (Grid)
- Items: Real‑time prediction, Percentage‑based output, Color‑coded levels (Low/Med/High), Intuitive dashboard, Uses existing weather data.

### 6. Live Demo Simulation (Interactive Component)
- **Title:** See Flymply in Action
- **Description:** Experience how Flymply continuously updates turbulence risk in real time.
- **Feature:** Build a card showing a circular gauge or a large percentage (e.g., 14%). 
- **Logic:** Use a `useEffect` to make the number fluctuate slightly every 3 seconds to simulate "Live Data."
- **CTA:** "Launch Demo" button.

### 7. Feasibility & Who It's For
- **Feasibility:** Explain it's hardware-free, advisory-only, and uses proven AI techniques.
- **Audience:** Airlines, Pilots, Safety Teams, Research Institutes.

### 8. About & Footer
- **About:** Flymply is a proof‑of‑concept project developed to demonstrate how AI can predict clear‑air turbulence. Not intended to replace certified systems.
- **Footer:** Flymply — AI‑Based Clear‑Air Turbulence Prediction | Built by Team Flymply | Hackathon Project.

## 🚀 Technical Requirements
1. **Responsive Design:** Mobile-first approach.
2. **Scroll Animations:** Use `framer-motion` for sections to fade in as the user scrolls.
3. **Sticky Nav:** A clean navbar with the "Flymply" logo and a "Launch Demo" button.
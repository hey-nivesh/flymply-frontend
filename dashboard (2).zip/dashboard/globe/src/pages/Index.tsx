import { Suspense } from 'react';
import GlobeScene from '@/components/Globe/GlobeScene';

const Index = () => {
  return (
    <div className="relative min-h-[300vh] bg-background">
      <Suspense fallback={
        <div className="fixed inset-0 flex items-center justify-center bg-background">
          <div className="text-muted-foreground text-sm tracking-widest uppercase animate-pulse">
            Loading Globe...
          </div>
        </div>
      }>
        <GlobeScene />
      </Suspense>

      {/* Invisible scroll area for zoom control */}
      <div className="relative z-10 pointer-events-none min-h-[300vh]" />
    </div>
  );
};

export default Index;

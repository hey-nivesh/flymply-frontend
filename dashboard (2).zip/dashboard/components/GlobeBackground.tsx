'use client';

import dynamic from 'next/dynamic';
import { Suspense } from 'react';

const GlobeScene = dynamic(() => import('./Globe/GlobeScene'), {
    ssr: false,
});

export default function GlobeBackground() {
    return (
        <Suspense
            fallback={
                <div className="fixed inset-0 flex items-center justify-center bg-slate-950">
                    <div className="text-slate-400 text-sm tracking-widest uppercase animate-pulse">
                        Loading Globe...
                    </div>
                </div>
            }
        >
            <GlobeScene />
        </Suspense>
    );
}
